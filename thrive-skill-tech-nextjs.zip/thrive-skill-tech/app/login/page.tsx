import { AuthForm } from "@/components/forms/auth-form";

export default function LoginPage() {
  return (
    <section className="container-shell py-16">
      <AuthForm type="login" />
    </section>
  );
}
