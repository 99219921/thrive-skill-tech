import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function AdminLecturesPage() {
  return (
    <form className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Lecture Upload</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Input placeholder="Lecture Title" />
        <Input placeholder="Course Name" />
        <Input placeholder="Video URL / Storage Path" />
        <Input placeholder="Lesson Order" />
      </div>
      <Button className="mt-6">Upload Lecture</Button>
    </form>
  );
}
