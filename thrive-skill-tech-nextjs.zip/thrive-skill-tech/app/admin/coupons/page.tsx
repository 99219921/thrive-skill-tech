import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function AdminCouponsPage() {
  return (
    <form className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Coupon Management</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <Input placeholder="Coupon Code" />
        <Input placeholder="Discount %" />
        <Input placeholder="Expiry Date" />
      </div>
      <Button className="mt-6">Create Coupon</Button>
    </form>
  );
}
