import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

export default function WebsiteContentPage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Website Content Editor</h1>
      <p className="mt-2 text-sm text-zinc-400">Use this area later to connect CMS or admin-managed content APIs.</p>
      <div className="mt-6">
        <Textarea className="min-h-[240px]" defaultValue="Homepage hero and CTA content placeholder..." />
      </div>
      <Button className="mt-6">Save Content</Button>
    </div>
  );
}
