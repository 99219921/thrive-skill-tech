import { webinarLeads } from "@/lib/data";

export default function WebinarLeadsPage() {
  return (
    <div className="overflow-hidden rounded-3xl border border-white/10">
      <table className="w-full text-left text-sm">
        <thead className="bg-white/5 text-zinc-200">
          <tr>
            {["Name", "Phone", "Email", "Source"].map((head) => <th key={head} className="p-4">{head}</th>)}
          </tr>
        </thead>
        <tbody className="divide-y divide-white/10 text-zinc-300">
          {webinarLeads.map((row) => (
            <tr key={row.email}>
              <td className="p-4">{row.name}</td>
              <td className="p-4">{row.phone}</td>
              <td className="p-4">{row.email}</td>
              <td className="p-4">{row.source}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
