import { studentsTable } from "@/lib/data";

export default function AdminStudentsPage() {
  return (
    <div className="overflow-hidden rounded-3xl border border-white/10">
      <table className="w-full text-left text-sm">
        <thead className="bg-white/5 text-zinc-200">
          <tr>
            {["ID", "Name", "Course", "Status", "Progress"].map((head) => <th key={head} className="p-4">{head}</th>)}
          </tr>
        </thead>
        <tbody className="divide-y divide-white/10 text-zinc-300">
          {studentsTable.map((row) => (
            <tr key={row.id}>
              <td className="p-4">{row.id}</td>
              <td className="p-4">{row.name}</td>
              <td className="p-4">{row.course}</td>
              <td className="p-4">{row.status}</td>
              <td className="p-4">{row.progress}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
