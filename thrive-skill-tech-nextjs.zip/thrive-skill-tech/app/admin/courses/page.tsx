import { courses } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function AdminCoursesPage() {
  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
        <h1 className="text-2xl font-semibold text-white">Course Management</h1>
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <Input placeholder="Course Title" />
          <Input placeholder="Price" />
          <Input placeholder="Level" />
          <Input placeholder="Duration" />
        </div>
        <div className="mt-4 flex gap-3">
          <Button>Add Course</Button>
          <Button variant="outline">Save Draft</Button>
        </div>
      </div>

      <div className="grid gap-6">
        {courses.map((course) => (
          <div key={course.slug} className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h2 className="text-xl font-semibold text-white">{course.title}</h2>
                <p className="mt-2 text-sm text-zinc-400">{course.description}</p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline">Edit</Button>
                <Button variant="gold">Change Price</Button>
                <Button>Delete</Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
