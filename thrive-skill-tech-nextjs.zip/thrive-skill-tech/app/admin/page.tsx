import { adminStats } from "@/lib/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { currency } from "@/lib/utils";

export default function AdminDashboardPage() {
  return (
    <>
      <div className="rounded-3xl border border-white/10 bg-gradient-to-r from-brand-gold/10 to-brand-green/10 p-8">
        <h1 className="text-3xl font-bold text-white">Admin Overview</h1>
        <p className="mt-2 text-zinc-300">Manage courses, learners, leads, payments, and site content from one place.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        <Card><CardHeader><CardTitle>Total Students</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-white">{adminStats.totalStudents}</div></CardContent></Card>
        <Card><CardHeader><CardTitle>Revenue This Month</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-white">{currency(adminStats.revenueThisMonth)}</div></CardContent></Card>
        <Card><CardHeader><CardTitle>Active Courses</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-white">{adminStats.activeCourses}</div></CardContent></Card>
        <Card><CardHeader><CardTitle>Pending Doubts</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-white">{adminStats.pendingDoubts}</div></CardContent></Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Revenue Snapshot</CardTitle></CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-3">
              {["Course Sales", "Webinar Upsells", "Installments"].map((item, index) => (
                <div key={item} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <div className="text-sm text-zinc-400">{item}</div>
                  <div className="mt-2 text-xl font-bold text-white">{currency([312000, 95500, 75000][index])}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Quick Actions</CardTitle></CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2">
            {["Add Course", "Create Coupon", "Upload Lecture", "Review Leads"].map((item) => (
              <button key={item} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-left text-sm text-zinc-300 transition hover:bg-white/10">
                {item}
              </button>
            ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
