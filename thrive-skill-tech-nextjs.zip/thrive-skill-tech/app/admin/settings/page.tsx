import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { siteConfig } from "@/lib/site";

export default function SettingsPage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Company Settings</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Input defaultValue={siteConfig.name} />
        <Input defaultValue={siteConfig.tagline} />
        <Input defaultValue={siteConfig.email} />
        <Input defaultValue={siteConfig.phone} />
        <Input defaultValue={siteConfig.website} />
        <Input defaultValue={siteConfig.udyam} />
      </div>
      <Button className="mt-6">Save Settings</Button>
    </div>
  );
}
