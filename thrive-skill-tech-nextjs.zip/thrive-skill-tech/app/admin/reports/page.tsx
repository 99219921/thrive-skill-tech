export default function ReportsPage() {
  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
      {[
        ["Enrollment Report", "Monthly enrollment trend"],
        ["Revenue Report", "Payments and installment health"],
        ["Completion Report", "Lesson completion and certificate readiness"],
        ["Lead Report", "Webinar lead performance"]
      ].map(([title, desc]) => (
        <div key={title} className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <p className="mt-2 text-sm text-zinc-400">{desc}</p>
        </div>
      ))}
    </div>
  );
}
