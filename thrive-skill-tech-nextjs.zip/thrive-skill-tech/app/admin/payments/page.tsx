import { paymentsTable } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { currency } from "@/lib/utils";

export default function AdminPaymentsPage() {
  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-brand-gold/20 bg-brand-gold/10 p-6 text-sm text-zinc-100">
        Razorpay integration placeholder: create backend order before checkout, send order_id to frontend, verify payment signature through secure backend webhook after payment success.
      </div>

      <div className="overflow-hidden rounded-3xl border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-zinc-200">
            <tr>
              {["ID", "Student", "Course", "Amount", "Status", "Action"].map((head) => <th key={head} className="p-4">{head}</th>)}
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10 text-zinc-300">
            {paymentsTable.map((row) => (
              <tr key={row.id}>
                <td className="p-4">{row.id}</td>
                <td className="p-4">{row.student}</td>
                <td className="p-4">{row.course}</td>
                <td className="p-4">{currency(row.amount)}</td>
                <td className="p-4">{row.status}</td>
                <td className="p-4"><Button size="sm" variant="outline">View Order</Button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
