import { Button } from "@/components/ui/button";

export default function AdminCertificatesPage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Certificate Manager</h1>
      <p className="mt-3 text-sm text-zinc-300">
        Manage templates, learner eligibility, download access, and issue status here.
      </p>
      <div className="mt-6 flex gap-3">
        <Button>Create Template</Button>
        <Button variant="outline">Issue Certificate</Button>
      </div>
    </div>
  );
}
