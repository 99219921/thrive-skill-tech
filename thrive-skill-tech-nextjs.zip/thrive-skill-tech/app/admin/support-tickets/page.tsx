import { supportTickets } from "@/lib/data";
import { Button } from "@/components/ui/button";

export default function SupportTicketsPage() {
  return (
    <div className="space-y-4">
      {supportTickets.map((item) => (
        <div key={item.id} className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="text-sm text-brand-gold">{item.id}</div>
              <h2 className="mt-1 text-lg font-semibold text-white">{item.subject}</h2>
              <p className="mt-2 text-sm text-zinc-400">User: {item.user} • Status: {item.status}</p>
            </div>
            <Button variant="outline">Resolve Ticket</Button>
          </div>
        </div>
      ))}
    </div>
  );
}
