export default function AdminLogoutPage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-sm text-zinc-300">
      Admin logout placeholder. Connect this route to session invalidation and redirect logic later.
    </div>
  );
}
