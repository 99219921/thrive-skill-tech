import { PageHero } from "@/components/public/page-hero";

export default function PolicyPage() {
  return (
    <>
      <PageHero
        badge="Policy"
        title="Privacy Policy"
        description="How Thrive Skill Tech collects, uses, and protects user information."
      />
      <section className="container-shell py-16">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 text-sm leading-8 text-zinc-300">

          <p>We collect basic user information such as name, phone number, email address, and learning preferences when a user registers for courses, webinars, or contact requests.</p>
          <p className="mt-4">This data is used to provide learning services, communicate updates, process enrollments, and improve platform experience. We do not sell personal data.</p>
          <p className="mt-4">Payment, authentication, and analytics integrations should be implemented with secure backend handling and verified third-party providers.</p>
          <p className="mt-4">Users may request correction or deletion of their information by contacting the company email listed on this website.</p>

        </div>
      </section>
    </>
  );
}
