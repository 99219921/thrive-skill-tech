import { AuthForm } from "@/components/forms/auth-form";

export default function SignupPage() {
  return (
    <section className="container-shell py-16">
      <AuthForm type="signup" />
    </section>
  );
}
