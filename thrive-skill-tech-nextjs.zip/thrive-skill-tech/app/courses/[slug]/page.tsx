import { notFound } from "next/navigation";
import { Award, Briefcase, Globe, PlayCircle, ShieldCheck } from "lucide-react";
import { PageHero } from "@/components/public/page-hero";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FAQList } from "@/components/faq-list";
import { courses } from "@/lib/data";
import { currency } from "@/lib/utils";

export function generateStaticParams() {
  return courses.map((course) => ({ slug: course.slug }));
}

export default async function CourseDetailPage({
  params
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const course = courses.find((item) => item.slug === slug);

  if (!course) notFound();

  return (
    <>
      <PageHero
        badge={course.badge ?? course.level}
        title={course.title}
        description={course.description}
      />

      <section className="container-shell py-16">
        <div className="grid gap-8 lg:grid-cols-[1fr_360px]">
          <div className="space-y-8">
            <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
              <h2 className="text-2xl font-semibold text-white">Course overview</h2>
              <p className="mt-4 text-sm leading-8 text-zinc-300">
                {course.title} is designed to give learners a practical, step-by-step learning journey with action-oriented modules and guided outcomes. The curriculum focuses on usable skills, consistent execution, and confidence-building.
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Badge className="gap-2"><PlayCircle className="h-4 w-4" /> {course.mode}</Badge>
                <Badge className="gap-2"><Globe className="h-4 w-4" /> English / Hindi / Marathi</Badge>
                <Badge className="gap-2"><Award className="h-4 w-4" /> Certificate Included</Badge>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
              <h3 className="text-xl font-semibold text-white">Who is this for</h3>
              <div className="mt-4 flex flex-wrap gap-3">
                {course.bestFor.map((item) => <Badge key={item}>{item}</Badge>)}
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
              <h3 className="text-xl font-semibold text-white">Modules</h3>
              <ul className="mt-4 grid gap-3 md:grid-cols-2">
                {course.modules.map((module) => (
                  <li key={module} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-zinc-300">
                    {module}
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
              <h3 className="text-xl font-semibold text-white">Course outcomes</h3>
              <ul className="mt-4 space-y-3 text-sm text-zinc-300">
                {course.outcomes.map((item) => <li key={item}>• {item}</li>)}
              </ul>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
              <h3 className="text-xl font-semibold text-white">Certificate & support</h3>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                  <ShieldCheck className="h-6 w-6 text-brand-green" />
                  <p className="mt-3 text-sm text-zinc-300">{course.certificate}</p>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/5 p-5">
                  <Briefcase className="h-6 w-6 text-brand-gold" />
                  <p className="mt-3 text-sm text-zinc-300">{course.support}</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="mb-5 text-2xl font-semibold text-white">FAQ</h3>
              <FAQList />
            </div>
          </div>

          <aside className="h-fit rounded-3xl border border-white/10 bg-white/5 p-6 lg:sticky lg:top-28">
            <div className="text-sm uppercase tracking-[0.2em] text-brand-gold">Price</div>
            <div className="mt-3 text-4xl font-bold text-white">{currency(course.price)}</div>
            <p className="mt-3 text-sm text-zinc-400">Duration: {course.duration}</p>
            <div className="mt-6 space-y-3">
              <Button className="w-full">Enroll Now</Button>
              <Button variant="outline" className="w-full">Talk to Counselor</Button>
            </div>

            <div className="mt-8 rounded-2xl border border-brand-green/20 bg-brand-green/10 p-4 text-sm text-zinc-200">
              Razorpay checkout flow can connect here later via backend order creation and webhook verification.
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
