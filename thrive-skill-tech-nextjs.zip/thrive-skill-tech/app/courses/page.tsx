import Link from "next/link";
import { PageHero } from "@/components/public/page-hero";
import { CourseCard } from "@/components/course-card";
import { SectionHeading } from "@/components/section-heading";
import { CourseComparison } from "@/components/public/course-comparison";
import { Button } from "@/components/ui/button";
import { courses } from "@/lib/data";

export default function CoursesPage() {
  return (
    <>
      <PageHero
        badge="Programs"
        title="Courses built for practical growth"
        description="Explore beginner-friendly and flagship learning programs crafted to help you build skills, confidence, and career direction."
      />

      <section className="container-shell py-16">
        <div className="grid gap-6 lg:grid-cols-2">
          {courses.map((course) => <CourseCard key={course.slug} course={course} />)}
        </div>
      </section>

      <section className="container-shell py-16">
        <SectionHeading
          title="Course comparison"
          description="Compare the starter and flagship path before choosing your next step."
        />
        <CourseComparison />
      </section>

      <section className="container-shell py-16">
        <div className="rounded-[2rem] border border-white/10 bg-gradient-to-r from-brand-gold/10 to-brand-green/10 p-8">
          <h2 className="text-3xl font-bold text-white">Need counseling before joining Career King?</h2>
          <p className="mt-3 max-w-2xl text-zinc-300">
            Talk to our team to understand whether the flagship path matches your goals, current skill level, and career ambitions.
          </p>
          <div className="mt-6">
            <Link href="/contact"><Button>Apply / Counseling Request</Button></Link>
          </div>
        </div>
      </section>
    </>
  );
}
