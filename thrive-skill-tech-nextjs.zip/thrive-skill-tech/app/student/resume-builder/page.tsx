import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function ResumeBuilderPage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Resume Builder</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Input placeholder="Full Name" />
        <Input placeholder="Email" />
        <Input placeholder="Phone" />
        <Input placeholder="Skills" />
        <Input placeholder="Education" />
        <Input placeholder="LinkedIn URL" />
        <div className="md:col-span-2"><Textarea placeholder="Projects / Experience" /></div>
      </div>
      <Button className="mt-6">Generate Resume</Button>
    </div>
  );
}
