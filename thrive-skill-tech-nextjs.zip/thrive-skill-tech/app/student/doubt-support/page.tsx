import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function DoubtSupportPage() {
  return (
    <form className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Doubt Support</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Input placeholder="Subject" />
        <Input placeholder="Course / Module" />
        <div className="md:col-span-2">
          <Textarea placeholder="Describe your doubt in detail" />
        </div>
      </div>
      <Button className="mt-6">Submit Doubt</Button>
    </form>
  );
}
