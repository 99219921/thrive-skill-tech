import { Button } from "@/components/ui/button";

export default function ReferEarnPage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Refer & Earn</h1>
      <p className="mt-2 text-sm text-zinc-300">Share your referral code and earn rewards when friends join eligible programs.</p>
      <div className="mt-6 rounded-2xl border border-brand-gold/20 bg-brand-gold/10 p-5">
        <div className="text-sm text-zinc-400">Referral Code</div>
        <div className="mt-2 text-3xl font-bold tracking-widest text-white">THRIVE-TEJ-2026</div>
      </div>
      <Button className="mt-6">Copy Code</Button>
    </div>
  );
}
