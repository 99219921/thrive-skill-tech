import { announcements, studentCourses } from "@/lib/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function StudentDashboardPage() {
  return (
    <>
      <div className="rounded-3xl border border-white/10 bg-gradient-to-r from-brand-gold/10 to-brand-green/10 p-8">
        <h1 className="text-3xl font-bold text-white">Welcome back, Student</h1>
        <p className="mt-2 text-zinc-300">Continue building momentum with your practical learning journey.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
        {[
          ["Enrolled Courses", "2"],
          ["Completed Lessons", "29"],
          ["Progress %", "45%"],
          ["Certificates", "1"]
        ].map(([title, value]) => (
          <Card key={title}>
            <CardHeader><CardTitle>{title}</CardTitle></CardHeader>
            <CardContent><div className="text-3xl font-bold text-white">{value}</div></CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <CardHeader><CardTitle>Continue Watching</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {studentCourses.map((course) => (
              <div key={course.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h3 className="font-semibold text-white">{course.title}</h3>
                    <p className="text-sm text-zinc-400">{course.nextLesson}</p>
                  </div>
                  <div className="text-sm text-brand-gold">{course.progress}%</div>
                </div>
                <div className="mt-3 h-2 rounded-full bg-white/10">
                  <div className="h-2 rounded-full bg-brand-green" style={{ width: `${course.progress}%` }} />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Announcements</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {announcements.map((item) => (
              <div key={item} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-zinc-300">{item}</div>
            ))}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
