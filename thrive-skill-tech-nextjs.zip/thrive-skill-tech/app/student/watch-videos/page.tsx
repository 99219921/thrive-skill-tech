import { Button } from "@/components/ui/button";

export default function WatchVideosPage() {
  const lessons = [
    "Introduction",
    "Content Ideas Framework",
    "Scripting Basics",
    "Editing Basics",
    "Growth Strategy"
  ];

  return (
    <div className="grid gap-6 xl:grid-cols-[1fr_320px]">
      <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
        <div className="grid h-[380px] place-items-center rounded-2xl border border-dashed border-white/10 bg-black/40 text-zinc-500">
          Video player placeholder
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button>Mark Complete</Button>
          <Button variant="outline">Download Notes</Button>
        </div>
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/5 p-4">
        <h2 className="px-2 py-3 text-lg font-semibold text-white">Lessons</h2>
        <div className="space-y-2">
          {lessons.map((lesson, index) => (
            <button key={lesson} className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-left text-sm text-zinc-300 transition hover:bg-white/10">
              {index + 1}. {lesson}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
