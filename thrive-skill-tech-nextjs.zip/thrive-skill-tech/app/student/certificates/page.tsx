import { Button } from "@/components/ui/button";

export default function CertificatesPage() {
  const certificates = ["Content Creation Master Course Certificate"];

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {certificates.map((item) => (
        <div key={item} className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h2 className="text-xl font-semibold text-white">{item}</h2>
          <p className="mt-2 text-sm text-zinc-400">Available for download</p>
          <Button className="mt-4">Download Certificate</Button>
        </div>
      ))}
    </div>
  );
}
