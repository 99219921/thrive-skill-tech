export default function DownloadsPage() {
  const notes = ["SEO Basics PDF", "Reels Growth Checklist", "AI Tools Prompt Pack"];

  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Notes & Downloads</h1>
      <div className="mt-6 space-y-3">
        {notes.map((note) => (
          <div key={note} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-zinc-300">
            {note}
          </div>
        ))}
      </div>
    </div>
  );
}
