export default function StudentLogoutPage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6 text-sm text-zinc-300">
      Logout placeholder. Connect this route to auth session clearing and redirect logic later.
    </div>
  );
}
