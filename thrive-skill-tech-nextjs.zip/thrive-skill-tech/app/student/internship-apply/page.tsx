import { internshipListings } from "@/lib/data";
import { Button } from "@/components/ui/button";

export default function InternshipApplyPage() {
  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
      {internshipListings.map((item) => (
        <div key={item.title} className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h2 className="text-xl font-semibold text-white">{item.title}</h2>
          <p className="mt-2 text-sm text-zinc-400">{item.company}</p>
          <p className="mt-3 text-sm text-zinc-300">{item.location}</p>
          <p className="mt-1 text-sm text-brand-gold">{item.stipend}</p>
          <Button className="mt-5">Apply</Button>
        </div>
      ))}
    </div>
  );
}
