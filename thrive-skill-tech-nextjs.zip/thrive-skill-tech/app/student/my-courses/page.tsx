import { studentCourses } from "@/lib/data";

export default function StudentCoursesPage() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {studentCourses.map((course) => (
        <div key={course.id} className="rounded-3xl border border-white/10 bg-white/5 p-6">
          <h1 className="text-xl font-semibold text-white">{course.title}</h1>
          <p className="mt-2 text-sm text-zinc-400">
            {course.lessonsCompleted}/{course.totalLessons} lessons completed
          </p>
          <div className="mt-4 h-2 rounded-full bg-white/10">
            <div className="h-2 rounded-full bg-brand-green" style={{ width: `${course.progress}%` }} />
          </div>
          <p className="mt-3 text-sm text-zinc-300">Next lesson: {course.nextLesson}</p>
        </div>
      ))}
    </div>
  );
}
