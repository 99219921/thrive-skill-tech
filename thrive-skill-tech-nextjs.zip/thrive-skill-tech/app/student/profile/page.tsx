import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function ProfilePage() {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
      <h1 className="text-2xl font-semibold text-white">Profile Settings</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Input placeholder="Full Name" defaultValue="Student User" />
        <Input placeholder="Email" defaultValue="student@example.com" />
        <Input placeholder="Phone" defaultValue="9876543210" />
        <Input placeholder="Preferred Language" defaultValue="English" />
      </div>
      <Button className="mt-6">Save Changes</Button>
    </div>
  );
}
