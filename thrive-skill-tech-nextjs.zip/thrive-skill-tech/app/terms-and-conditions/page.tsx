import { PageHero } from "@/components/public/page-hero";

export default function PolicyPage() {
  return (
    <>
      <PageHero
        badge="Policy"
        title="Terms & Conditions"
        description="Terms governing the use of Thrive Skill Tech website and learning platform."
      />
      <section className="container-shell py-16">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 text-sm leading-8 text-zinc-300">

          <p>By using this website, users agree to provide accurate registration information, use the platform responsibly, and not misuse course content, dashboards, or downloadable resources.</p>
          <p className="mt-4">Access to student and admin areas is role-based. Any unauthorized use, scraping, content copying, or account abuse may result in access restriction.</p>
          <p className="mt-4">Course structure, pricing, webinar schedules, and support features may evolve over time to improve learner outcomes.</p>
          <p className="mt-4">Additional legal language can be inserted here after review by a professional legal advisor.</p>

        </div>
      </section>
    </>
  );
}
