import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const body = await request.json();
  // TODO: validate payload and persist to database
  return NextResponse.json({ success: true, lead: body });
}
