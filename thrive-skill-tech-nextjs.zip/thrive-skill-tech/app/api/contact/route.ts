import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const body = await request.json();
  // TODO: send email / create CRM ticket
  return NextResponse.json({ success: true, message: body });
}
