import { NextResponse } from "next/server";

export async function POST() {
  // TODO: verify Razorpay webhook signature here before updating payment state
  return NextResponse.json({ received: true });
}
