import { CheckCircle2 } from "lucide-react";
import { PageHero } from "@/components/public/page-hero";
import { WebinarForm } from "@/components/forms/webinar-form";

export default function WebinarPage() {
  const benefits = [
    "Understand practical career paths in digital skills",
    "Learn how content, marketing, and AI tools connect to income",
    "Get clarity on course roadmap and outcomes",
    "Free certificate guidance and next steps"
  ];

  return (
    <>
      <PageHero
        badge="Free Webinar"
        title="Register for the free webinar"
        description="Join a focused introductory session to understand skill-based career opportunities and how to start with the right learning path."
      />

      <section className="container-shell grid gap-8 py-16 lg:grid-cols-[1fr_420px]">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
          <h2 className="text-2xl font-semibold text-white">Why join?</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {benefits.map((item) => (
              <div key={item} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <CheckCircle2 className="h-5 w-5 text-brand-green" />
                <p className="mt-3 text-sm text-zinc-300">{item}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 rounded-2xl border border-brand-gold/20 bg-brand-gold/10 p-5 text-sm text-zinc-100">
            Free certificate mention can be highlighted during or after the webinar journey depending on company policy and attendance completion logic.
          </div>
        </div>

        <WebinarForm />
      </section>
    </>
  );
}
