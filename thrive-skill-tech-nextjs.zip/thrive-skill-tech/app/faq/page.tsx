import { PageHero } from "@/components/public/page-hero";
import { FAQList } from "@/components/faq-list";

export default function FAQPage() {
  return (
    <>
      <PageHero
        badge="FAQ"
        title="Common questions"
        description="Everything learners usually ask before joining Thrive Skill Tech."
      />
      <section className="container-shell py-16">
        <FAQList />
      </section>
    </>
  );
}
