import { PageHero } from "@/components/public/page-hero";

export default function PolicyPage() {
  return (
    <>
      <PageHero
        badge="Policy"
        title="Refund Policy"
        description="Refund, cancellation, and enrollment policy for Thrive Skill Tech programs."
      />
      <section className="container-shell py-16">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-8 text-sm leading-8 text-zinc-300">

          <p>Refunds, if applicable, depend on the specific program rules, onboarding status, and service usage stage. Learners should review current policy terms before purchase.</p>
          <p className="mt-4">Once premium onboarding, mentorship access, or protected digital content has been substantially delivered, refunds may be limited according to company policy.</p>
          <p className="mt-4">For support with payment-related issues, users should contact the official company email or phone number for case-specific review.</p>
          <p className="mt-4">Exact refund windows and approval logic can later be connected to backend order status handling.</p>

        </div>
      </section>
    </>
  );
}
