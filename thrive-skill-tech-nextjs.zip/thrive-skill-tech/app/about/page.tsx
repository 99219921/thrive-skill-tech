import { PageHero } from "@/components/public/page-hero";
import { SectionHeading } from "@/components/section-heading";
import { siteConfig } from "@/lib/site";

export default function AboutPage() {
  return (
    <>
      <PageHero
        badge="About Thrive Skill Tech"
        title="Practical learning for the real world"
        description="Thrive Skill Tech is a registered Indian skill-development platform helping students, freelancers, and professionals move from learning to earning through practical training, guided execution, and career-oriented support."
      />

      <section className="container-shell py-16">
        <div className="grid gap-10 lg:grid-cols-2">
          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <SectionHeading title="Who we are" />
            <p className="text-sm leading-8 text-zinc-300">
              Thrive Skill Tech was created to bridge the gap between online information and practical execution. We focus on industry-relevant skills like Digital Marketing, SEO, Content Creation, AI Tools, Video Editing, and Social Media Marketing in a way that feels accessible, structured, and action-oriented.
            </p>
            <p className="mt-5 text-sm leading-8 text-zinc-300">
              Our programs are designed for people who want more than theory. Whether someone is a student, early-stage creator, freelancer, or working professional, the goal is to build usable skills that support income, employability, and long-term career growth.
            </p>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/5 p-8">
            <SectionHeading title="What makes us different" />
            <ul className="space-y-4 text-sm leading-7 text-zinc-300">
              <li>• Practical modules with direct application.</li>
              <li>• Career-focused structure from learning to earning.</li>
              <li>• Guidance on resume, internships, and professional direction.</li>
              <li>• Flexible format with live and recorded learning support.</li>
              <li>• Accessible communication across English, Hindi, and Marathi.</li>
            </ul>
          </div>
        </div>

        <div className="mt-10 rounded-3xl border border-brand-green/20 bg-brand-green/10 p-8">
          <h2 className="text-2xl font-semibold text-white">Company Details</h2>
          <div className="mt-5 grid gap-4 text-sm text-zinc-200 md:grid-cols-2">
            <div><strong>Founder:</strong> {siteConfig.founder}</div>
            <div><strong>Udyam Number:</strong> {siteConfig.udyam}</div>
            <div><strong>Email:</strong> {siteConfig.email}</div>
            <div><strong>Phone:</strong> {siteConfig.phone}</div>
            <div className="md:col-span-2"><strong>Address:</strong> {siteConfig.address}</div>
          </div>
        </div>
      </section>
    </>
  );
}
