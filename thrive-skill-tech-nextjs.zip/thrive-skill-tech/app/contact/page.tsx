import { Mail, MapPin, Phone } from "lucide-react";
import { PageHero } from "@/components/public/page-hero";
import { ContactForm } from "@/components/forms/contact-form";
import { siteConfig } from "@/lib/site";

export default function ContactPage() {
  return (
    <>
      <PageHero
        badge="Contact"
        title="Let’s help you choose the right next step"
        description="Reach out for course guidance, webinar support, partnerships, or general questions."
      />

      <section className="container-shell grid gap-8 py-16 lg:grid-cols-[0.95fr_1.05fr]">
        <div className="space-y-6">
          {[
            [Phone, siteConfig.phone],
            [Mail, siteConfig.email],
            [MapPin, siteConfig.address]
          ].map(([Icon, value], idx) => (
            <div key={idx} className="rounded-3xl border border-white/10 bg-white/5 p-6">
              <Icon className="h-6 w-6 text-brand-gold" />
              <p className="mt-3 text-sm leading-7 text-zinc-300">{value}</p>
            </div>
          ))}

          <div className="rounded-3xl border border-white/10 bg-white/5 p-6">
            <h3 className="text-lg font-semibold text-white">Google Maps</h3>
            <div className="mt-4 grid h-64 place-items-center rounded-2xl border border-dashed border-white/10 bg-black/30 text-sm text-zinc-500">
              Embedded Google Maps placeholder
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <ContactForm />
          <a
            href={`https://wa.me/${siteConfig.whatsapp}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex rounded-2xl border border-brand-green/20 bg-brand-green/10 px-5 py-3 text-sm font-medium text-white"
          >
            Chat on WhatsApp
          </a>
        </div>
      </section>
    </>
  );
}
